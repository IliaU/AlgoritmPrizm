﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlgoritmPrizm
{
    public partial class FLic : Form
    {
        private string pwd = DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString() + "115446";
        private string OLDlblInformLicText;

        private DataTable dtModule;

        // Конструктор
        public FLic()
        {
            this.OLDlblInformLicText = null;
            Com.Lic.onRegNewKey += new EventHandler<Com.LicLib.onLicItem>(Lic_onRegNewKey);
            InitializeComponent();

            this.Text += Com.Lic.Version;
            this.panelGetActivationKey.Visible = false;
        }

        // Загрузка формы
        private void Form_Lic_Load(object sender, EventArgs e)
        {
            if (this.OLDlblInformLicText == null) this.OLDlblInformLicText = this.lblInformLic.Text;
            else this.lblInformLic.Text = this.OLDlblInformLicText;


            // Проверяем валидность объекта
            if (Com.Lic.isValid)
            {
                this.btn_RegLic_Click(null, null);
                this.panInformLic.Visible = false;
                this.panelinformTekLic.Visible = true;

                this.lblInformLic.Text = this.lblInformLic.Text.Replace(@"@ValiDate", Com.Lic.ValidDateYYYYMMDD.ToString().Substring(6) + "."
                    + Com.Lic.ValidDateYYYYMMDD.ToString().Substring(4, 2) + @"."
                    + Com.Lic.ValidDateYYYYMMDD.ToString().Substring(0, 4));

                List<string> tmpScn = new List<string>();
/*                foreach (string sitem in Com.ScenariyFarm.ListScenariyName())
                {
                    Lib.UScenariy Uscn = new Lib.UScenariy(sitem, "Info", null);
                    if (Uscn.ValidLicData() != 0)
                    {
                        bool flag = true;
                        foreach (string item in tmpScn)
                        {
                            if (sitem == item) flag = false;
                        }
                        if (flag) tmpScn.Add(sitem);
                    }
                }*/
                
                this.lblInformLic.Text = this.lblInformLic.Text.Replace("@Module", string.Join(",",tmpScn));
            }
            else
            {
                this.panInformLic.Visible = true;
                this.panelinformTekLic.Visible = false;
                this.txtBoxActivNumber.Text = Com.Lic.GetActivNumber();
            }

            // Меняем размер, чтобы было удобнее работать
            this.Size = new Size(this.Size.Width, 50 + this.panelAbout.Size.Height + this.panelinformTekLic.Size.Height 
                + (this.panInformLic.Visible?50:0)
                + (this.panelGetActivationKey.Visible?this.panelGetActivationKey.Size.Height:0));
        }

        // Событие возникающее при успешной регистрации лицензионного ключа
        private void Lic_onRegNewKey(object sender, Com.LicLib.onLicItem e)
        {
            Form_Lic_Load(null, null);
        }

        // Запуск генератора ключа
        private void btnCreateKey_Click(object sender, EventArgs e)
        {
            try
            {
                //if (this.dtModule != null && this.dtModule.Rows.Count > 0)
                //{
                    List<string> ScnFullNameList = new List<string>();
                    /*foreach (DataRow item in this.dtModule.Rows)
                    {
                        if (bool.Parse(item["SelectedItm"].ToString()))
                        {
                            ScnFullNameList.Add(item["Module"].ToString());
                        }
                    }*/

                    string tmp = null;
                    tmp = Com.Lic.GetLicNumber(textBoxNewActivNumber.Text, this.textBoxNewLicDate.Text, this.txtBoxInfo.Text.Replace("@Info", ""), this.chBox_HashUserOS.Checked, ScnFullNameList);

                    if (tmp != null)
                    {
                        this.textBoxNewLicKey.Visible = true;
                        this.textBoxNewLicKey.Text = tmp;
                    }
                //}
                //else throw new ApplicationException("Вы не выбрали ни одного сценария которым может воспользоваться клиент.");

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        // Регистрация новой лицензии
        private void btn_RegLic_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBoxLicKey.Text == this.pwd || sender == null)
                {
                    if(sender != null) this.panelGetActivationKey.Visible = true;
                    if (this.dtModule == null)
                    {
                        this.dtModule = new DataTable("Module");
                        this.dtModule.Columns.Add(new DataColumn("Module", Type.GetType("System.String")));
                        this.dtModule.Columns.Add(new DataColumn("SelectedItm", Type.GetType("System.Boolean")));
                        this.dgModule.DataSource = this.dtModule; 
                    }
                    /*
                    if (this.dtModule.Rows.Count == 0)
                    {
                        foreach (string item in Com.ScenariyFarm.ListScenariyName())
	                    {
                            DataRow nrow = this.dtModule.NewRow();
                            nrow["Module"] = item;
                            nrow["SelectedItm"] = true;
                            this.dtModule.Rows.Add(nrow);
	                    }
                    }*/
                }
                else Com.Lic.RegNewKey(txtBoxLicKey.Text, txtBoxActivNumber.Text);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

            //Собственно можно обновить статус
            if (sender!=null) Form_Lic_Load(null, null);
        }

        // Пользователь отправляет сообщение
        private void linkLabelEmail_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //(Lic.isValid == false ? this.txtBoxActivNumber.Text : "2")

            //System.Diagnostics.Process.Start(@"www.yandex.ru");

            // проверяем наличие лицензии
            if (Com.Lic.isValid) // Лицензия уже существует, следовательно это не запрос лицензии
            {
                System.Diagnostics.Process.Start(@"mailto:support@aks.ru?subject=Програмный комплекс " + Com.Lic.ProductSid +
                   @"&cc=support@aks.ru&body=Добрый день уважаемая потдержка компании Алгоритм");
            }
            else
            {
                System.Diagnostics.Process.Start(@"mailto:support@aks.ru?subject=Запрос получения лицензионного ключа к програмному комплексу " + Com.Lic.ProductSid +
                    @"&cc=support@aks.ru&body=Мой номер активации:" + Environment.NewLine + "\r\n" + this.txtBoxActivNumber.Text);
            }
        }

        // Пользователь решил попасть на официальный сайт компании
        private void linkLabelWWW_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(@"http://www.aks.ru/");
        }

        // Пользователь запрашивает лицензионный ключь
        private void btnSendActivNumber_Click(object sender, EventArgs e)
        {
            linkLabelEmail_LinkClicked(null, null);
        }
        
        // Пользователь захотел продлить лицензию
        private void btn_Prolongat_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"mailto:support@aks.ru?subject=Запрос продления лицензионного ключа к програмному комплексу " + Com.Lic.ProductSid +
    @"&cc=support@aks.ru&body=Мой номер активации:" + Environment.NewLine + "\r\n" + Com.Lic.GetActivNumber());
        }

        // Пользователь ввёл лицензию для пролонгации
        private void btnProlongSetKey_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBox_KeyProlong.Text.Replace("\r\n", "") == this.pwd) 
                {
                    txtBox_KeyProlong.Text=txtBox_KeyProlong.Text.Replace("\r\n", ""); 
                    this.panelGetActivationKey.Visible = true; 
                }
                else Com.Lic.RegNewKey(txtBox_KeyProlong.Text, Com.Lic.GetActivNumber());
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

            //Собственно можно обновить статус
            Form_Lic_Load(null, null);
        }

        // Мониторим клавиши которые нажимает пользователь во время ввода в окно txtBox_KeyProlong
        private void txtBox_KeyProlong_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 13) btnProlongSetKey_Click(null, null);
        }
    }
}
