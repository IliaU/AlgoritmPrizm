﻿namespace AlgoritmPrizm
{
    partial class FLic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FLic));
            this.panInformLic = new System.Windows.Forms.Panel();
            this.btnSendActivNumber = new System.Windows.Forms.Button();
            this.btn_RegLic = new System.Windows.Forms.Button();
            this.txtBoxLicKey = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoxActivNumber = new System.Windows.Forms.TextBox();
            this.lblActivNumber1 = new System.Windows.Forms.Label();
            this.lblActivNumber = new System.Windows.Forms.Label();
            this.panelinformTekLic = new System.Windows.Forms.Panel();
            this.btnProlongSetKey = new System.Windows.Forms.Button();
            this.txtBox_KeyProlong = new System.Windows.Forms.TextBox();
            this.btn_Prolongat = new System.Windows.Forms.Button();
            this.lblInformLic = new System.Windows.Forms.Label();
            this.panelGetActivationKey = new System.Windows.Forms.Panel();
            this.dgModule = new System.Windows.Forms.DataGridView();
            this.Module = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedItm = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.chBox_HashUserOS = new System.Windows.Forms.CheckBox();
            this.txtBoxInfo = new System.Windows.Forms.TextBox();
            this.textBoxNewLicDate = new System.Windows.Forms.TextBox();
            this.textBoxNewLicKey = new System.Windows.Forms.TextBox();
            this.btnCreateKey = new System.Windows.Forms.Button();
            this.textBoxNewActivNumber = new System.Windows.Forms.TextBox();
            this.panelAbout = new System.Windows.Forms.Panel();
            this.linkLabelWWW = new System.Windows.Forms.LinkLabel();
            this.linkLabelEmail = new System.Windows.Forms.LinkLabel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panInformLic.SuspendLayout();
            this.panelinformTekLic.SuspendLayout();
            this.panelGetActivationKey.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgModule)).BeginInit();
            this.panelAbout.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panInformLic
            // 
            this.panInformLic.Controls.Add(this.btnSendActivNumber);
            this.panInformLic.Controls.Add(this.btn_RegLic);
            this.panInformLic.Controls.Add(this.txtBoxLicKey);
            this.panInformLic.Controls.Add(this.label1);
            this.panInformLic.Controls.Add(this.txtBoxActivNumber);
            this.panInformLic.Controls.Add(this.lblActivNumber1);
            this.panInformLic.Controls.Add(this.lblActivNumber);
            this.panInformLic.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panInformLic.ForeColor = System.Drawing.Color.Red;
            this.panInformLic.Location = new System.Drawing.Point(0, 263);
            this.panInformLic.Name = "panInformLic";
            this.panInformLic.Size = new System.Drawing.Size(822, 23);
            this.panInformLic.TabIndex = 2;
            // 
            // btnSendActivNumber
            // 
            this.btnSendActivNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSendActivNumber.ForeColor = System.Drawing.Color.Navy;
            this.btnSendActivNumber.Location = new System.Drawing.Point(488, 58);
            this.btnSendActivNumber.Name = "btnSendActivNumber";
            this.btnSendActivNumber.Size = new System.Drawing.Size(322, 23);
            this.btnSendActivNumber.TabIndex = 13;
            this.btnSendActivNumber.Text = "Запросить лицензию по электронной почте";
            this.btnSendActivNumber.UseVisualStyleBackColor = true;
            this.btnSendActivNumber.Click += new System.EventHandler(this.btnSendActivNumber_Click);
            // 
            // btn_RegLic
            // 
            this.btn_RegLic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_RegLic.ForeColor = System.Drawing.Color.Navy;
            this.btn_RegLic.Location = new System.Drawing.Point(488, 108);
            this.btn_RegLic.Name = "btn_RegLic";
            this.btn_RegLic.Size = new System.Drawing.Size(322, 23);
            this.btn_RegLic.TabIndex = 12;
            this.btn_RegLic.Text = "Активировать лицензию";
            this.btn_RegLic.UseVisualStyleBackColor = true;
            this.btn_RegLic.Click += new System.EventHandler(this.btn_RegLic_Click);
            // 
            // txtBoxLicKey
            // 
            this.txtBoxLicKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtBoxLicKey.ForeColor = System.Drawing.Color.Red;
            this.txtBoxLicKey.Location = new System.Drawing.Point(4, 108);
            this.txtBoxLicKey.Multiline = true;
            this.txtBoxLicKey.Name = "txtBoxLicKey";
            this.txtBoxLicKey.Size = new System.Drawing.Size(455, 50);
            this.txtBoxLicKey.TabIndex = 11;
            this.txtBoxLicKey.Text = "@LicKey";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(0, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(512, 22);
            this.label1.TabIndex = 10;
            this.label1.Text = "Если у вас уже есть лицензионный ключ, то введите его для активации программы.";
            // 
            // txtBoxActivNumber
            // 
            this.txtBoxActivNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtBoxActivNumber.ForeColor = System.Drawing.Color.Red;
            this.txtBoxActivNumber.Location = new System.Drawing.Point(4, 59);
            this.txtBoxActivNumber.Name = "txtBoxActivNumber";
            this.txtBoxActivNumber.Size = new System.Drawing.Size(455, 21);
            this.txtBoxActivNumber.TabIndex = 9;
            this.txtBoxActivNumber.Text = "@ActivNumber";
            // 
            // lblActivNumber1
            // 
            this.lblActivNumber1.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblActivNumber1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblActivNumber1.Location = new System.Drawing.Point(0, 34);
            this.lblActivNumber1.Name = "lblActivNumber1";
            this.lblActivNumber1.Size = new System.Drawing.Size(822, 22);
            this.lblActivNumber1.TabIndex = 8;
            this.lblActivNumber1.Text = "Если у вас нет лицензионного ключа, то необходимо отправить следующую информацию:" +
    " ";
            // 
            // lblActivNumber
            // 
            this.lblActivNumber.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblActivNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblActivNumber.Location = new System.Drawing.Point(0, 0);
            this.lblActivNumber.Name = "lblActivNumber";
            this.lblActivNumber.Size = new System.Drawing.Size(822, 34);
            this.lblActivNumber.TabIndex = 7;
            this.lblActivNumber.Text = "Вы используете не легальную копию програмы.";
            this.lblActivNumber.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panelinformTekLic
            // 
            this.panelinformTekLic.Controls.Add(this.btnProlongSetKey);
            this.panelinformTekLic.Controls.Add(this.txtBox_KeyProlong);
            this.panelinformTekLic.Controls.Add(this.btn_Prolongat);
            this.panelinformTekLic.Controls.Add(this.lblInformLic);
            this.panelinformTekLic.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelinformTekLic.Location = new System.Drawing.Point(0, 147);
            this.panelinformTekLic.Name = "panelinformTekLic";
            this.panelinformTekLic.Size = new System.Drawing.Size(822, 116);
            this.panelinformTekLic.TabIndex = 1;
            // 
            // btnProlongSetKey
            // 
            this.btnProlongSetKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnProlongSetKey.ForeColor = System.Drawing.Color.Navy;
            this.btnProlongSetKey.Location = new System.Drawing.Point(488, 75);
            this.btnProlongSetKey.Name = "btnProlongSetKey";
            this.btnProlongSetKey.Size = new System.Drawing.Size(322, 23);
            this.btnProlongSetKey.TabIndex = 15;
            this.btnProlongSetKey.Text = "Активировать дополнительную лицензию";
            this.btnProlongSetKey.UseVisualStyleBackColor = true;
            this.btnProlongSetKey.Click += new System.EventHandler(this.btnProlongSetKey_Click);
            // 
            // txtBox_KeyProlong
            // 
            this.txtBox_KeyProlong.Location = new System.Drawing.Point(4, 65);
            this.txtBox_KeyProlong.Multiline = true;
            this.txtBox_KeyProlong.Name = "txtBox_KeyProlong";
            this.txtBox_KeyProlong.Size = new System.Drawing.Size(455, 44);
            this.txtBox_KeyProlong.TabIndex = 14;
            this.txtBox_KeyProlong.Text = "@LicKey";
            this.txtBox_KeyProlong.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtBox_KeyProlong_KeyUp);
            // 
            // btn_Prolongat
            // 
            this.btn_Prolongat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Prolongat.ForeColor = System.Drawing.Color.Navy;
            this.btn_Prolongat.Location = new System.Drawing.Point(488, 7);
            this.btn_Prolongat.Name = "btn_Prolongat";
            this.btn_Prolongat.Size = new System.Drawing.Size(322, 23);
            this.btn_Prolongat.TabIndex = 13;
            this.btn_Prolongat.Text = "Запросить лицензию продления по почте";
            this.btn_Prolongat.UseVisualStyleBackColor = true;
            this.btn_Prolongat.Click += new System.EventHandler(this.btn_Prolongat_Click);
            // 
            // lblInformLic
            // 
            this.lblInformLic.AutoSize = true;
            this.lblInformLic.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInformLic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblInformLic.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblInformLic.Location = new System.Drawing.Point(0, 0);
            this.lblInformLic.Name = "lblInformLic";
            this.lblInformLic.Size = new System.Drawing.Size(0, 15);
            this.lblInformLic.TabIndex = 0;
            // 
            // panelGetActivationKey
            // 
            this.panelGetActivationKey.Controls.Add(this.dgModule);
            this.panelGetActivationKey.Controls.Add(this.chBox_HashUserOS);
            this.panelGetActivationKey.Controls.Add(this.txtBoxInfo);
            this.panelGetActivationKey.Controls.Add(this.textBoxNewLicDate);
            this.panelGetActivationKey.Controls.Add(this.textBoxNewLicKey);
            this.panelGetActivationKey.Controls.Add(this.btnCreateKey);
            this.panelGetActivationKey.Controls.Add(this.textBoxNewActivNumber);
            this.panelGetActivationKey.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelGetActivationKey.Location = new System.Drawing.Point(0, 286);
            this.panelGetActivationKey.Name = "panelGetActivationKey";
            this.panelGetActivationKey.Size = new System.Drawing.Size(822, 244);
            this.panelGetActivationKey.TabIndex = 3;
            this.panelGetActivationKey.Visible = false;
            // 
            // dgModule
            // 
            this.dgModule.AllowUserToAddRows = false;
            this.dgModule.AllowUserToDeleteRows = false;
            this.dgModule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgModule.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Module,
            this.SelectedItm});
            this.dgModule.Location = new System.Drawing.Point(4, 59);
            this.dgModule.Name = "dgModule";
            this.dgModule.Size = new System.Drawing.Size(334, 104);
            this.dgModule.TabIndex = 6;
            this.dgModule.Visible = false;
            // 
            // Module
            // 
            this.Module.DataPropertyName = "Module";
            this.Module.HeaderText = "Сценарии";
            this.Module.Name = "Module";
            this.Module.ReadOnly = true;
            this.Module.Width = 200;
            // 
            // SelectedItm
            // 
            this.SelectedItm.DataPropertyName = "SelectedItm";
            this.SelectedItm.HeaderText = "Разрешить";
            this.SelectedItm.Name = "SelectedItm";
            this.SelectedItm.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SelectedItm.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.SelectedItm.Width = 80;
            // 
            // chBox_HashUserOS
            // 
            this.chBox_HashUserOS.AutoSize = true;
            this.chBox_HashUserOS.Location = new System.Drawing.Point(275, 35);
            this.chBox_HashUserOS.Name = "chBox_HashUserOS";
            this.chBox_HashUserOS.Size = new System.Drawing.Size(184, 17);
            this.chBox_HashUserOS.TabIndex = 5;
            this.chBox_HashUserOS.Text = "Привязать к пользователю OS";
            this.chBox_HashUserOS.UseVisualStyleBackColor = true;
            // 
            // txtBoxInfo
            // 
            this.txtBoxInfo.Location = new System.Drawing.Point(488, 6);
            this.txtBoxInfo.Multiline = true;
            this.txtBoxInfo.Name = "txtBoxInfo";
            this.txtBoxInfo.Size = new System.Drawing.Size(331, 76);
            this.txtBoxInfo.TabIndex = 4;
            this.txtBoxInfo.Text = "@Info";
            // 
            // textBoxNewLicDate
            // 
            this.textBoxNewLicDate.Location = new System.Drawing.Point(4, 33);
            this.textBoxNewLicDate.Name = "textBoxNewLicDate";
            this.textBoxNewLicDate.Size = new System.Drawing.Size(192, 20);
            this.textBoxNewLicDate.TabIndex = 3;
            this.textBoxNewLicDate.Text = "@YYYYMMDD";
            // 
            // textBoxNewLicKey
            // 
            this.textBoxNewLicKey.Location = new System.Drawing.Point(3, 169);
            this.textBoxNewLicKey.Multiline = true;
            this.textBoxNewLicKey.Name = "textBoxNewLicKey";
            this.textBoxNewLicKey.Size = new System.Drawing.Size(815, 63);
            this.textBoxNewLicKey.TabIndex = 2;
            this.textBoxNewLicKey.Text = "@LicKey";
            this.textBoxNewLicKey.Visible = false;
            // 
            // btnCreateKey
            // 
            this.btnCreateKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCreateKey.ForeColor = System.Drawing.Color.Navy;
            this.btnCreateKey.Location = new System.Drawing.Point(344, 58);
            this.btnCreateKey.Name = "btnCreateKey";
            this.btnCreateKey.Size = new System.Drawing.Size(115, 23);
            this.btnCreateKey.TabIndex = 1;
            this.btnCreateKey.Text = "Генерить ключ";
            this.btnCreateKey.UseVisualStyleBackColor = true;
            this.btnCreateKey.Click += new System.EventHandler(this.btnCreateKey_Click);
            // 
            // textBoxNewActivNumber
            // 
            this.textBoxNewActivNumber.Location = new System.Drawing.Point(4, 6);
            this.textBoxNewActivNumber.Name = "textBoxNewActivNumber";
            this.textBoxNewActivNumber.Size = new System.Drawing.Size(455, 20);
            this.textBoxNewActivNumber.TabIndex = 0;
            this.textBoxNewActivNumber.Text = "@ActivNumber";
            // 
            // panelAbout
            // 
            this.panelAbout.Controls.Add(this.linkLabelWWW);
            this.panelAbout.Controls.Add(this.linkLabelEmail);
            this.panelAbout.Controls.Add(this.label3);
            this.panelAbout.Controls.Add(this.label2);
            this.panelAbout.Controls.Add(this.pictureBox1);
            this.panelAbout.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelAbout.Location = new System.Drawing.Point(0, 0);
            this.panelAbout.Name = "panelAbout";
            this.panelAbout.Size = new System.Drawing.Size(822, 147);
            this.panelAbout.TabIndex = 0;
            // 
            // linkLabelWWW
            // 
            this.linkLabelWWW.AutoSize = true;
            this.linkLabelWWW.Location = new System.Drawing.Point(500, 92);
            this.linkLabelWWW.Name = "linkLabelWWW";
            this.linkLabelWWW.Size = new System.Drawing.Size(63, 13);
            this.linkLabelWWW.TabIndex = 5;
            this.linkLabelWWW.TabStop = true;
            this.linkLabelWWW.Text = "www.aks.ru";
            // 
            // linkLabelEmail
            // 
            this.linkLabelEmail.AutoSize = true;
            this.linkLabelEmail.Location = new System.Drawing.Point(500, 105);
            this.linkLabelEmail.Name = "linkLabelEmail";
            this.linkLabelEmail.Size = new System.Drawing.Size(164, 13);
            this.linkLabelEmail.TabIndex = 3;
            this.linkLabelEmail.TabStop = true;
            this.linkLabelEmail.Text = "support@aks.ru, algoritm@aks.ru";
            this.linkLabelEmail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelEmail_LinkClicked);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label3.Location = new System.Drawing.Point(404, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(337, 75);
            this.label3.TabIndex = 2;
            this.label3.Text = "Контакты для связи: \r\n\r\n    WWW\r\n    Email\r\n    Телефоны       +7 (495) 748-11-66" +
    ", +7 (495) 258-89-05/06";
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(822, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "Правообладателем является компания \"Алгоритм\"";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AlgoritmPrizm.Properties.Resources.AKS;
            this.pictureBox1.Location = new System.Drawing.Point(4, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(394, 113);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // FLic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(822, 530);
            this.Controls.Add(this.panInformLic);
            this.Controls.Add(this.panelinformTekLic);
            this.Controls.Add(this.panelAbout);
            this.Controls.Add(this.panelGetActivationKey);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FLic";
            this.Text = "Лицензирование v: ";
            this.Load += new System.EventHandler(this.Form_Lic_Load);
            this.panInformLic.ResumeLayout(false);
            this.panInformLic.PerformLayout();
            this.panelinformTekLic.ResumeLayout(false);
            this.panelinformTekLic.PerformLayout();
            this.panelGetActivationKey.ResumeLayout(false);
            this.panelGetActivationKey.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgModule)).EndInit();
            this.panelAbout.ResumeLayout(false);
            this.panelAbout.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panInformLic;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxActivNumber;
        private System.Windows.Forms.Label lblActivNumber1;
        private System.Windows.Forms.Label lblActivNumber;
        private System.Windows.Forms.TextBox txtBoxLicKey;
        private System.Windows.Forms.Panel panelinformTekLic;
        private System.Windows.Forms.Panel panelGetActivationKey;
        private System.Windows.Forms.Panel panelAbout;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCreateKey;
        private System.Windows.Forms.TextBox textBoxNewActivNumber;
        private System.Windows.Forms.TextBox textBoxNewLicKey;
        private System.Windows.Forms.Button btn_RegLic;
        private System.Windows.Forms.Label lblInformLic;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.LinkLabel linkLabelEmail;
        private System.Windows.Forms.TextBox textBoxNewLicDate;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel linkLabelWWW;
        private System.Windows.Forms.TextBox txtBoxInfo;
        private System.Windows.Forms.Button btnSendActivNumber;
        private System.Windows.Forms.Button btn_Prolongat;
        private System.Windows.Forms.Button btnProlongSetKey;
        private System.Windows.Forms.TextBox txtBox_KeyProlong;
        private System.Windows.Forms.CheckBox chBox_HashUserOS;
        private System.Windows.Forms.DataGridView dgModule;
        private System.Windows.Forms.DataGridViewTextBoxColumn Module;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SelectedItm;
    }
}