﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.Lib
{
    public enum EventEn
    {
        Empty, Dump, Message, Warning, Error, FatalError, Trace
    }
}
