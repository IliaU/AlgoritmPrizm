﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.Lib
{
    /// <summary>
    /// Версия ФФД
    /// </summary>
    public enum FfdEn
    {
        v1_05, v1_2
    }
}
