﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.Com.LicLib
{
    /// <summary>
    /// Класс реализующий логику построения основы на смещении
    /// </summary>
    public class Osnova
    {
        private int Smechenie;

        /// <remarks>Конструктор</remarks>
        public Osnova(int Smechenie)
        {
            this.Smechenie = Smechenie;
        }

        /// <remarks>Получение основы нужной длины которую будем применять для шифрования</remarks>
        public string GetOsnova(int LenString)
        {
            string rez = this.Smechenie.ToString();

            while (rez.Length < LenString)
            {
                rez = rez + rez;
            }

            rez = rez.Substring(0, LenString);

            return rez;
        }
    }
}
