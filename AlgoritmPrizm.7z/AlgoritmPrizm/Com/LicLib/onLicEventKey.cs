﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.Com.LicLib
{
    public class onLicEventKey : EventArgs
    {
        public string MachineName { get; private set; }
        public string UserName { get; private set; }
        public string ActivNumber { get; private set; }
        public string LicKey { get; private set; }
        public int ValidToYYYYMMDD; //{ get; private set; }
        public string Info { get; private set; }
        public bool HashUserOS { get; private set; }
        /// <summary>
        /// Список залицензированных модулей
        /// </summary>
        public List<string> ScnFullNameList;// { get; private set; }


        /// <remarks>Конструктор</remarks>
        public onLicEventKey(string MachineName, string UserName, string ActivNumber, string LicKey, int ValidToYYYYMMDD, string Info, bool HashUserOS, List<string> ScnFullNameList)
        {
            this.MachineName = MachineName;
            this.UserName = UserName;
            this.ActivNumber = ActivNumber;
            this.LicKey = LicKey;
            this.ValidToYYYYMMDD = ValidToYYYYMMDD;
            this.Info = Info;
            this.HashUserOS = HashUserOS;
            this.ScnFullNameList = ScnFullNameList;
        }
    }
}
