﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.Com.LicLib
{
    /// <summary>
    /// Класс для хранения результатов собятий класса реализующего лицензирование
    /// </summary>
    public class onLicItem : EventArgs
    {
        public Boolean Action = true;
        public onLicEventKey _LicEventKey { get; private set; }

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="Menu"></param>
        public onLicItem(onLicEventKey _LicEventKey)
        {
            this._LicEventKey = _LicEventKey;
        }
    }
}
