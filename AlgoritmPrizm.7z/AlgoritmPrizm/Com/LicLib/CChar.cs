﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.Com.LicLib
{
    /// <summary>
    /// Класс реализующий хранение конкретного символа, который будет использоваться для системы счисления
    /// </summary>
    public class CChar
    {
        public char cchar;

        /// <remarks>Конструктор</remarks>
        public CChar(char cchar)
        {
            this.cchar = cchar;
        }
    }
}
