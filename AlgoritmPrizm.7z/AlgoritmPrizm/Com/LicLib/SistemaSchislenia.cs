﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.Com.LicLib
{
    /// <summary>
    /// Класс реализующий логику перевода из 10 в систему счисления и обратно
    /// </summary>
    public partial class SistemaSchislenia
    {
        /// <summary>
        /// Набор символов используемый в данной системе счисления
        /// </summary>
        private List<CChar> Simbols;

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="CountCchar"></param>
        public SistemaSchislenia(int CountCchar)
        {
            this.Simbols = new List<CChar>();

            ApplicationException app = new ApplicationException("Слишком большая разрядность выбирете поменьше");
            try
            {
                if (CountCchar >= 1) this.Simbols.Add((new CChar('0')));
                if (CountCchar >= 2) this.Simbols.Add((new CChar('1')));
                if (CountCchar >= 3) this.Simbols.Add((new CChar('2')));
                if (CountCchar >= 4) this.Simbols.Add((new CChar('3')));
                if (CountCchar >= 5) this.Simbols.Add((new CChar('4')));
                if (CountCchar >= 6) this.Simbols.Add((new CChar('5')));
                if (CountCchar >= 7) this.Simbols.Add((new CChar('6')));
                if (CountCchar >= 8) this.Simbols.Add((new CChar('7')));
                if (CountCchar >= 9) this.Simbols.Add((new CChar('8')));
                if (CountCchar >= 10) this.Simbols.Add((new CChar('9')));
                if (CountCchar >= 11) this.Simbols.Add((new CChar('A')));
                if (CountCchar >= 12) this.Simbols.Add((new CChar('B')));
                if (CountCchar >= 13) this.Simbols.Add((new CChar('C')));
                if (CountCchar >= 14) this.Simbols.Add((new CChar('D')));
                if (CountCchar >= 15) this.Simbols.Add((new CChar('E')));
                if (CountCchar >= 16) this.Simbols.Add((new CChar('F')));
                if (CountCchar >= 17) this.Simbols.Add((new CChar('G')));
                if (CountCchar >= 18) this.Simbols.Add((new CChar('H')));
                if (CountCchar >= 19) this.Simbols.Add((new CChar('I')));
                if (CountCchar >= 20) this.Simbols.Add((new CChar('J')));
                if (CountCchar >= 21) this.Simbols.Add((new CChar('K')));
                if (CountCchar >= 22) this.Simbols.Add((new CChar('L')));
                if (CountCchar >= 23) this.Simbols.Add((new CChar('M')));
                if (CountCchar >= 24) this.Simbols.Add((new CChar('N')));
                if (CountCchar >= 25) this.Simbols.Add((new CChar('O')));
                if (CountCchar >= 26) this.Simbols.Add((new CChar('P')));
                if (CountCchar >= 27) this.Simbols.Add((new CChar('Q')));
                if (CountCchar >= 28) this.Simbols.Add((new CChar('R')));
                if (CountCchar >= 29) this.Simbols.Add((new CChar('S')));
                if (CountCchar >= 30) this.Simbols.Add((new CChar('T')));
                if (CountCchar >= 31) this.Simbols.Add((new CChar('U')));
                if (CountCchar >= 32) this.Simbols.Add((new CChar('V')));
                if (CountCchar >= 33) this.Simbols.Add((new CChar('W')));
                if (CountCchar >= 34) this.Simbols.Add((new CChar('X')));
                if (CountCchar >= 35) this.Simbols.Add((new CChar('Y')));
                if (CountCchar >= 36) this.Simbols.Add((new CChar('Z')));
                //
                if (CountCchar >= 37) throw app;
            }
            catch (Exception)
            {
                throw;
            }

        }

        /// <remarks>Конвертация 10 разрядного числа в созданную в этом классе</remarks>
        public string IntToX(int i10)
        {
            string rez = "";
            int CountRaz = this.Simbols.Count;

            if (i10 == 0) return "0";

            // Пробегаем циклом
            while (i10 > 0)
            {
                int ostatok = i10 - (Math.Abs(i10 / CountRaz) * (CountRaz));
                rez = this.Simbols[ostatok].cchar.ToString() + rez;

                // Если цыфра меньше чем разрядность то нет смысла выделять целую часть при делении можно идти на выход
                if (i10 < CountRaz) { i10 = 0; continue; }

                // Если есть необходимость то делаем деление после вычета остатка и идём на следующий цикл, для подсчёта следующего разряда
                i10 = Math.Abs((i10 - ostatok) / CountRaz);
            }

            return rez;
        }

        /// <remarks>Конвертация числа созданного в этом классе в 10 разряднуюсистему исчисления</remarks>
        public int XToInt(string str)
        {
            int rez = 0;
            int CountRaz = this.Simbols.Count;
            int MnoRaz = 1;       // Множитель разряда

            if (str == null || str == string.Empty) return 0;

            for (int i = str.Length; i > 0; i--)
            {
                if (i == str.Length) MnoRaz = 1;
                else MnoRaz = int.Parse(Math.Pow(CountRaz, str.Length - i).ToString());

                rez = (getIndexChar((str.ToCharArray())[i - 1]) * MnoRaz) + rez;
            }

            return rez;
        }

        /// <remarks>Конвертация символа в конкретное число</remarks>
        private int getIndexChar(Char c)
        {
            int rez = 0;

            for (int i = 0; i < this.Simbols.Count; i++)
            {
                if (this.Simbols[i].cchar == c) return i;
            }

            return rez;
        }
    }
}
