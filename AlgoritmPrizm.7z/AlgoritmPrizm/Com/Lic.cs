﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Win32;

namespace AlgoritmPrizm.Com
{
    /// <summary>
    /// Класс для реализации лицензирования и шифровки и дешифровки строк
    /// </summary>
    public static class Lic
    {
        #region Private Param
        /// <summary>
        /// Текущая версия модуля лицензирования
        /// </summary>
        private static int _Version = 1;

        /// <summary>
        /// Уникальный идентификатор продукта
        /// </summary>
        private static string _ProductSid = "AlgoritmPrizm";

        /// <summary>
        /// Количество символов означающие смещение которе содержится в зашифровоном коде
        /// </summary>
        private static int _KolSimSmechenie = 4;

        /// <summary>
        /// Ключ, который проверяется для получения положительного результата
        /// </summary>
        private static Int64 Key;

        /// <summary>
        /// отображает состояние лицензии, если лицензия прошла, значит true
        /// </summary>
        private static bool _isValid = false;

        /// <summary>
        /// Текущиe валидныt ключb
        /// </summary>
        public static List<Com.LicLib.onLicEventKey> _LicKey = new List<LicLib.onLicEventKey>();
        #endregion

        #region Public Param
        /// <summary>
        /// Уникальный идентификатор продукта
        /// </summary>
        public static string ProductSid { get { return _ProductSid; } private set { } }

        /// <summary>
        /// Количество символов означающие смещение которе содержится в зашифровоном коде
        /// </summary>
        public static int KolSimSmechenie { get { return _KolSimSmechenie; } private set { } }

        /// <summary>
        /// Текущая версия модуля лицензирования
        /// </summary>
        public static int Version { get { return _Version; } private set { } }

        /// <summary>
        /// Имя текущей машины
        /// </summary>
        public static string MachineName { get { return Environment.MachineName; } private set { } }

        /// <summary>
        /// Имя пользователя
        /// </summary>
        public static string UserName { get { return Environment.UserName; } private set { } }

        /// <summary>
        /// |Отображает состояние лицензии, если лицензия прошла, значит true
        /// </summary>
        public static bool isValid { get { return _isValid; } private set { } }

        /// <summary>
        /// Текущие валидные ключи
        /// </summary>
        public static List<Com.LicLib.onLicEventKey> LicKey { get { return _LicKey; } private set { } }

        /// <summary>
        /// Текущий валидный ключ
        /// </summary>
        public static int ValidDateYYYYMMDD { get; private set; }

        /// <summary>
        /// Событие начала создания нового ключа
        /// </summary>
        public static event EventHandler<LicLib.onLicItem> onCreatingLicKey;

        /// <summary>
        /// Событие окончания создания нового ключа
        /// </summary>
        public static event EventHandler<LicLib.onLicEventKey> onCreatedLicKey;

        /// <summary>
        /// Событие регистрации нового ключа
        /// </summary>
        public static event EventHandler<LicLib.onLicItem> onRegNewKey;

        /// <summary>
        /// Событие после успешной регистрации нового ключа
        /// </summary>
        public static event EventHandler<LicLib.onLicEventKey> onRegNewKeyAfte;

        /// <summary>
        /// Событие проверки валидности ключа
        /// </summary>
        public static event EventHandler<LicLib.onLicEventKey> onIsValidLicKey;
        #endregion

        #region Public Method
        /// <summary>
        /// Получаем ключ который нужно отправить автору, чтобы он генерил ключ ответа
        /// </summary>
        /// <returns>Номер активации</returns>
        public static string GetActivNumber()
        {
            //string t=InCode(sme, "fd$");                 // Шифруем используюя смежение this.Key.ToString()
            //string Z = DeCode(t);

            return MachineName + @"@" + UserName + ":(" + InCode(GetCurrentKey().ToString()) + ")";
            //Lic.MachineName + @"@" + Lic.UserName + " - (" + Lic.GetActivNumber() + ")";
        }

        /// <summary>
        /// Получаем ключ лиценции на основе номера активации
        /// </summary>
        /// <param name="ActivNumber">Код активации</param>
        /// <param name="Toyyyymmdd">Дата до которой действует эта лицензия</param>
        /// <param name="Info">Информация о лицензии</param>
        /// <param name="HashUserOS">Делать привязку к пользователю или нет</param>
        /// <returns>Собственно ключь, который можно отправлять пользователю</returns>
        public static string GetLicNumber(string ActivNumber, string Toyyyymmdd, string Info, bool HashUserOS, List<string> ScnFullNameList)
        {
            string rez = "";
            string[] temp;
            string MaName = null;
            string UName = null;
            string key;
            int yyyymmdd = 0;

            ApplicationException appNull = new ApplicationException("Не введёна строка активации.");
            ApplicationException appformat = new ApplicationException("Не верный формат строки активации.");
            try
            {
                // Парсим
                if (ActivNumber == null || ActivNumber == string.Empty) throw appNull;
                temp = ActivNumber.Split('@');
                if (temp.Length != 2) throw appformat;

                MaName = temp[0].Trim();
                temp = temp[1].Replace("(", "").Replace(")", "").Split(':');
                if (temp.Length != 2) throw appformat;
                UName = temp[0].Trim();
                ActivNumber = temp[1].Trim();
                try { yyyymmdd = int.Parse(Toyyyymmdd); }
                catch (Exception) { throw new ApplicationException("Не правильно введена дата, до которой действует лицензия."); }

                // Собственно раскодируем ключ
                key = DeCode(ActivNumber);

                // Если махинаций не обнаружено, то генирим требуемый ключ 
                int sme = GetSmechenie();
                string str = string.Join(",", ScnFullNameList.ToArray());
                rez = InCode(key + "-" + _ProductSid + "-" + yyyymmdd + "-" + (HashUserOS ? UName : "Everyone") + "{" + string.Join(",", ScnFullNameList.ToArray()) + "}");
            }
            catch (Exception) { throw; }

            // Сохранение информации о лицензионном ключе
            LicLib.onLicEventKey nLic = new LicLib.onLicEventKey(MaName, UName, ActivNumber, rez, yyyymmdd, Info, HashUserOS, ScnFullNameList);

            // Вызов события отображающего информацию о сгенерированном ключе
            // Создаём аргументы
            LicLib.onLicItem MyArgs = new LicLib.onLicItem(nLic);
            // Если есть подпись в других классах то выполняем это событие
            if (onCreatingLicKey != null) { onCreatingLicKey.Invoke(MyArgs, MyArgs); }
            // После выполения анализируем результат если есть подтверждение то выполняем событие
            if (MyArgs.Action && onCreatedLicKey != null)
            {
                onCreatedLicKey.Invoke(nLic, nLic);
            }

            return rez;
        }


        /// <summary>
        /// Проверка валидности ключа, если он валиден, то меняем статус и возвращаем true
        /// </summary>
        /// <param name="LicKey">Лицензионный ключ</param>
        /// <returns>Возвращаем true если ключь валиден</returns>
        public static bool IsValidLicKey(string LicKey)
        {
            return IsValidLicKey(new LicLib.onLicEventKey(Com.Lic.MachineName, Com.Lic.UserName, Com.Lic.GetActivNumber(), LicKey, Com.Lic.ValidDateYYYYMMDD, "", false, null), true, false);
        }

        /// <summary>
        /// Регистрация нового ключа если ключ не валиден, то возвращаем ошибку
        /// </summary>
        /// <param name="LicKey">Лицензионный ключь</param>
        /// <param name="ActivNumber">Номер активации чтобы сохранить информацию например в логе</param>
        public static void RegNewKey(string LicKey, string ActivNumber)
        {
            ApplicationException appNull = new ApplicationException("Не введён лицензионный ключ.");
            ApplicationException appformat = new ApplicationException("Не верный формат строки лицензионного ключа.");
            ApplicationException appNotValid = new ApplicationException("Ключ лицензии не подходит.");
            ApplicationException appNotValidProgramName = new ApplicationException("Ключ лицензии не для этой программы.");
            ApplicationException appNotValidDateTo = new ApplicationException("Срок лицензии вышел.");
            ApplicationException appNotUserOS = new ApplicationException("Пользователь OS не имеет права использовать эту лицензию.");
            try
            {   // Проверка валидности
                if (LicKey == null || LicKey == string.Empty) throw appNull;
                if (IsNotValidCharFromLicKey(LicKey)) throw appformat;

                // Парсим
                string[] temp = DeCode(LicKey).Split('-');
                if (temp.Length != 4) throw appformat;

                // Получаем шифрованный ключ клиента если он указан, если не указан, используем текущий
                string TempKey;
                string TempMachineName;
                string TempUserName;
                if (ActivNumber == null || ActivNumber == string.Empty)
                {
                    TempKey = GetCurrentKey().ToString();
                    TempMachineName = MachineName;
                    TempUserName = UserName;
                }
                else
                {
                    TempKey = ActivNumber.Substring(ActivNumber.LastIndexOf("(") + 1).Replace(@")", "");
                    TempKey = DeCode(TempKey);

                    TempMachineName = ActivNumber.Substring(0, ActivNumber.IndexOf(@"@"));
                    TempUserName = ActivNumber.Substring(TempMachineName.Length + 1, ActivNumber.IndexOf(@":") - TempMachineName.Length - 1);
                }

                // Проверка лицензии
                if (TempKey != temp[0].Trim() || _ProductSid != temp[1].Trim())
                {
                    if (_ProductSid != temp[1].Trim()) throw appNotValidProgramName;
                    else throw appNotValid;
                }
                try
                {
                    if (int.Parse(temp[2]) < int.Parse(((DateTime.Now.Year * 10000) + (DateTime.Now.Month * 100) + DateTime.Now.Day).ToString()))
                    {
                        throw appNotValidDateTo;
                    }
                    else
                    {
                        if (ValidDateYYYYMMDD < int.Parse(temp[2])) ValidDateYYYYMMDD = int.Parse(temp[2]);
                    }
                }
                catch (Exception) { throw appNotValidDateTo; }

                // Проверка на привязку к пользователю
                string[] strtmpMod = temp[3].Split('{');
                List<string> module = new List<string>();
                if (strtmpMod.Length != 2)
                {
                    throw appformat;
                }
                else
                {
                    foreach (string item in strtmpMod[1].Replace("}", "").Split(','))
                    {
                        module.Add(item);
                    }
                }
                temp[3] = strtmpMod[0];
                if (temp[3].ToUpper() != "Everyone".ToUpper() && temp[3].ToUpper() != UserName.ToUpper()) throw appNotUserOS;


                // Вызов события отображающего о успешном добавлении ключа лицензии
                // Создаём аргументы
                LicLib.onLicEventKey newLicEventKey = new LicLib.onLicEventKey(TempMachineName, TempUserName, ActivNumber, LicKey, int.Parse(temp[2]), null, (temp[3].ToUpper() != "Everyone".ToUpper() ? true : false), module);
                LicLib.onLicItem MyArgs = new LicLib.onLicItem(newLicEventKey);
                // Если есть подпись в других классах то выполняем это событие
                if (onRegNewKey != null) { onRegNewKey.Invoke(MyArgs, MyArgs); }
                // После выполения анализируем результат обработки со стороны классов выполняющих обработку данного события
                if (MyArgs.Action)
                {
                    if (newLicEventKey.ScnFullNameList == null) newLicEventKey.ScnFullNameList = module;
                    if (newLicEventKey.ValidToYYYYMMDD == 0) newLicEventKey.ValidToYYYYMMDD = ValidDateYYYYMMDD;

                    // Переводим объект в валидное состояние
                    ValidDateYYYYMMDD = int.Parse(temp[2]);
                    _LicKey.Add(newLicEventKey);
                    _isValid = true;

                    if (onRegNewKeyAfte != null) { onRegNewKeyAfte.Invoke(MyArgs, newLicEventKey); }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        //
        /// <summary>
        /// Регистрация нового ключа если ключ не валиден, то возвращаем ошибку
        /// </summary>
        /// <param name="newKey">Лицензионный ключь</param>
        public static void RegNewKey(LicLib.onLicEventKey newKey)
        {
            RegNewKey(newKey.LicKey, null);
        }

        /// <remarks>Шифрование с использованием смещения</remarks>
        public static string InCode(string Text)
        {
            string rez = "";

            int Smechenie = GetSmechenie();

            // Создаём объект
            LicLib.SistemaSchislenia sissch = new LicLib.SistemaSchislenia(36);

            rez = sissch.IntToX(Smechenie);

            // Создаём объект основы который используется при кодировании
            string osnova = (new LicLib.Osnova(Smechenie)).GetOsnova(Text.Length);

            // Пробегаем посимвольно по тексту который надо зашифровать
            for (int i = 0; i < Text.Length; i++)
            {
                int t = int.Parse(CheckSum(Text.Substring(i, 1)).ToString());
                t = t + int.Parse(osnova.Substring(i, 1)) + Smechenie;
                rez = rez + "-" + sissch.IntToX(t);
            }

            return rez;
        }

        /// <remarks>Расшифровка кода</remarks>
        public static string DeCode(string code)
        {
            if (code == null || code == string.Empty) return "";
            string rez = "";


            // Разбиваем объет на массив
            string[] In = code.Split('-');

            // Создаём объект
            LicLib.SistemaSchislenia sissch = new LicLib.SistemaSchislenia(36);

            // вычисляем смещение которым закодировано
            int Smechenie = sissch.XToInt(In[0]);



            // Создаём объект основы который используется при раскодировании
            string osnova = (new LicLib.Osnova(Smechenie)).GetOsnova(In.Count() - 1);

            for (int i = 0; i < osnova.Length; i++)
            {
                int t = sissch.XToInt(In[i + 1]) - int.Parse(osnova.Substring(i, 1)) - Smechenie;

                rez = rez + Convert.ToChar(t).ToString();
            }

            return rez;
        }

        #endregion

        #region Private Method
        /// <summary>
        /// Проверка наличия не допустимых символов в лицензионном ключе
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        private static bool IsNotValidCharFromLicKey(string str)
        {
            bool rez = false;
            if (str == null || str == string.Empty) return true;
            if (str.IndexOf('-') == -1) return true;
            if (str.IndexOf('@') >= 0) return true;
            if (str.IndexOf(':') >= 0) return true;
            if (str.IndexOf('(') >= 0) return true;
            if (str.IndexOf(')') >= 0) return true;
            if (str.IndexOf(' ') >= 0) return true;

            return rez;
        }

        /// <remarks>Ключ, который необходимо зашифровать или расшифровать</remarks>
        private static Int64 GetCurrentKey()
        {
            if (Key == 0)
            {
                Key = CheckSum(MachineName);
                //Key += CheckSum(UserName);                   // Убираем привязку к пользователю
                Key += CheckSum(Environment.ProcessorCount.ToString());
                Key += CheckSum(_ProductSid);

                // Создаём объект реестра
                RegistryKey hklm = Registry.LocalMachine;
                try
                {
                    // Открываем папку для того, чтобы найти первый длинный символ
                    hklm = hklm.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList");
                    string[] strSubKey = hklm.GetSubKeyNames();
                    hklm.Close();

                    // Пробегаем циклом
                    for (int i = 0; i < strSubKey.Length; i++)
                    {
                        // Получаем ключ
                        if (strSubKey[i].Length > 10)
                        {
                            Key += CheckSum(strSubKey[i]);
                            i = strSubKey.Length;
                        }
                    }
                }
                catch { }
            }
            return Key;
        }

        /// <remarks>перевод символов в цифру</remarks>
        private static Int64 CheckSum(string text) //ToInteger2
        {
            Int64 rezult = 0;
            foreach (char item in text)
            {
                rezult = rezult + item;
            }
            return rezult;
        }

        /// <remarks>Получаем смещение с помощью которого нужно зашифровать инфу</remarks>
        private static int GetSmechenie()
        {
            double min = System.Math.Pow(10, _KolSimSmechenie - 1);
            double max = System.Math.Pow(10, _KolSimSmechenie) - 1;

            return (new Random()).Next(int.Parse(min.ToString()), int.Parse(max.ToString()));
        }

        /// <summary>
        /// Проверка валидности ключа, если он валиден возвращаем true
        /// </summary>
        /// <param name="LicKey">Лицензионный ключ</param>
        /// <param name="ChangeStatusIfValid">Переводим программу в валидный статус если текущий ключь валидный</param>
        /// <param name="ReturnExeptions">Возвращать исключения или нет</param>
        /// <returns>Возвращаем true если ключь валиден или ошибку если параметр ReturnExeptions содержит true</returns>
        private static bool IsValidLicKey(Com.LicLib.onLicEventKey LicKey, bool ChangeStatusIfValid, bool ReturnExeptions)
        {
            bool rez = false;

            ApplicationException appformat = new ApplicationException("Не верный формат строки лицензионного ключа.");
            ApplicationException appNotValid = new ApplicationException("Ключ лицензии не подходит.");
            ApplicationException appNotValidProgramName = new ApplicationException("Ключ лицензии не для этой программы.");
            ApplicationException appNotValidDateTo = new ApplicationException("Срок лицензии вышел.");
            ApplicationException appNotUserOS = new ApplicationException("Пользователь OS не имеет права использовать эту лицензию.");
            try
            {
                // Проверка валидности
                if (IsNotValidCharFromLicKey(LicKey.LicKey)) throw appformat;

                // Парсим
                string[] temp = DeCode(LicKey.LicKey).Split('-');
                if (temp.Length != 4)
                {
                    if (ReturnExeptions) throw appformat;
                    return rez;
                }

                // Проверка лицензии
                string TempKey = GetCurrentKey().ToString();
                if (TempKey != temp[0].Trim() || _ProductSid != temp[1].Trim())
                {
                    if (ReturnExeptions)
                    {
                        if (_ProductSid != temp[1].Trim()) throw appNotValidProgramName;
                        else throw appNotValid;
                    }
                    return rez;
                }
                try
                {
                    if (int.Parse(temp[2]) < int.Parse(((DateTime.Now.Year * 10000) + (DateTime.Now.Month * 100) + DateTime.Now.Day).ToString()))
                    {
                        if (ReturnExeptions) throw appNotValidDateTo;
                        return false;
                    }
                    else
                    {
                        if (ValidDateYYYYMMDD < int.Parse(temp[2])) ValidDateYYYYMMDD = int.Parse(temp[2]);
                    }
                }
                catch (Exception) { throw; }

                // Проверка на привязку к пользователю
                string[] strtmpMod = temp[3].Split('{');
                List<string> module = new List<string>();
                if (strtmpMod.Length != 2)
                {
                    if (ReturnExeptions) throw appformat;
                    return rez;
                }
                else
                {
                    foreach (string item in strtmpMod[1].Replace("}", "").Split(','))
                    {
                        module.Add(item);
                    }
                }
                temp[3] = strtmpMod[0];
                if (temp[3].ToUpper() != "Everyone".ToUpper() && temp[3].ToUpper() != UserName.ToUpper())
                {
                    if (ReturnExeptions) throw appNotUserOS;
                    return rez;
                }


                // Переводим объект в валидное состояние
                if (ChangeStatusIfValid)
                {
                    if (LicKey.ScnFullNameList == null) LicKey.ScnFullNameList = module;
                    if (LicKey.ValidToYYYYMMDD == 0) LicKey.ValidToYYYYMMDD = ValidDateYYYYMMDD;
                    _LicKey.Add(LicKey);
                    _isValid = true;
                }
                rez = true;

                // Вызов события отображающего попытку валидации ключа
                // Создаём аргументы
                LicLib.onLicEventKey MyArgs = new LicLib.onLicEventKey(MachineName, UserName, null, LicKey.LicKey, int.Parse(temp[2]), null, (temp[3].ToUpper() != "Everyone".ToUpper() ? true : false), null);

                // Если есть подпись в других классах то выполняем это событие
                if (onIsValidLicKey != null)
                {
                    onIsValidLicKey.Invoke(MyArgs, MyArgs);
                }

                return rez;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion
    }
}
