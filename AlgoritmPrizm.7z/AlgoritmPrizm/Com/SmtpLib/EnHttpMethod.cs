﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.Com.SmtpLib
{
    /// <summary>
    /// Метод используемый в HTTP клиенте, например POST
    /// </summary>
    public enum EnHttpMethod
    {
        POST,
        GET,
    }
}
