﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.BLL
{
    /// <summary>
    /// для списка товаров
    /// </summary>
    public class JsonGetInventorySbsinventorystoreqtys
    {
        public string link;
    }
}
