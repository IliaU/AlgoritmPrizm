﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.BLL
{
    public class JsonPrintFiscDocItemParam
    {
        public string cols;
        public string sort;
        public string document_sid;
    }
}
