﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.BLL
{
    public class JsonPrintFiscDocParam
    {
        public string cols;
        public string sid;
    }
}
