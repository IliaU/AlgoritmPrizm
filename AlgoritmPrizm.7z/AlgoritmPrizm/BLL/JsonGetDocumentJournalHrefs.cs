﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Newtonsoft.Json;

namespace AlgoritmPrizm.BLL
{
    /// <summary>
    /// Для парсинга списка строк в документе
    /// </summary>
    public class JsonGetDocumentJournalHrefs
    {
        public string controller_sid;
    }
}
