﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.BLL
{
    /// <summary>
    /// Для списка товаров
    /// </summary>
    public class JsonGetInventorySbsinventoryactiveprices
    {
        public string link;
        public double margin_amt;
        public double margin_with_tax_amt;
        public double margin_percent;
        public double markup_percent;
        public double coefficient;
    }
}
