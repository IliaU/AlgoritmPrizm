﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmPrizm.BLL
{
    /// <summary>
    /// для списка продуктов
    /// </summary>
    public class JsonGetInventoryHrefs
    {
        public string subsidiary_sid;
        public string dcs_sid;
        public string controller_sid;
        public string vendor_sid;
        public string tax_code_sid;
    }
}
